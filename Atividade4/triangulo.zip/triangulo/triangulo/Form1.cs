﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace triangulo
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;

        private void Txt3_Validated(object sender, EventArgs e)
        {
            errorProvider3.SetError(txt3, "");

            if (!double.TryParse(txt3.Text, out ladoC))
            {
                errorProvider3.SetError(txt3, "valor invalido!");
            }
        }

        private void BtnValidar_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txt1.Text, out ladoA) || !double.TryParse(txt2.Text, out ladoB) || !double.TryParse(txt3.Text, out ladoC))
            {
                MessageBox.Show("Valores invalidos");
                
            }
            else
            {
                if (ladoA < ladoB + ladoC && ladoA > Math.Abs(ladoB - ladoC)
                    && Math.Abs(ladoA - ladoC) < ladoB && ladoB < ladoA + ladoC
                    && Math.Abs(ladoA - ladoB) < ladoC && ladoC < ladoA + ladoB)
                {
                    if (ladoA == ladoB && ladoB == ladoC)
                    {
                        MessageBox.Show("Triangulo Equilatero");
                    }
                    else if (ladoA == ladoB || ladoA == ladoC || ladoC == ladoB)
                    {
                        MessageBox.Show("Triangulo Isosceles");
                    }
                    else
                    {
                        MessageBox.Show("Triangulo Escaleno");
                    }
                }
                else
                {
                    MessageBox.Show("Isso nao é um Triangulo!");
                }
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txt1.Clear();
            txt2.Clear();
            txt3.Clear();
            errorProvider1.SetError(txt1, "");
            errorProvider2.SetError(txt2, "");
            errorProvider3.SetError(txt3, "");

        }

        private void Txt2_Validated(object sender, EventArgs e)
        {
            errorProvider2.SetError(txt2, "");

            if (!double.TryParse(txt2.Text, out ladoB))
            {
                errorProvider2.SetError(txt2, "valor invalido!");
            }
        }

        private void Txt1_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txt1, "");

            if(!double.TryParse(txt1.Text, out ladoA))
            {
                errorProvider1.SetError(txt1, "valor invalido!");
            }
        }
    }
}
