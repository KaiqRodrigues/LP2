﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Configuration;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMC
{
    public partial class Form1 : Form

    {
        double peso;
        double altura;
        double resultado;
    
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Text = "";
            txtPeso.Text = "";
            txtIMC.Text = "";
        }

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(txtPeso.Text, out peso))
            {
                MessageBox.Show("Digite um peso valido!");
                txtPeso.Focus();
            }

        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("Digite uma altura valida!");
                txtAltura.Focus();
            }
        }

        private void txtIMC_Validated(object sender, EventArgs e)
        {
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            resultado = peso / Math.Pow(altura, 2);
            txtIMC.Text = resultado.ToString();
            
            if(resultado < 18.5)
            {
                MessageBox.Show("Classificação: Magreza");
            }
            else if(resultado < 24.9)
            {
                MessageBox.Show("Classificação: Normal");
            }
            else if (resultado < 29.9)
            {
                MessageBox.Show("Classificação: Sobrepeso");
            }
            else if (resultado < 39.9)
            {
                MessageBox.Show("Classificação: Obesidade");
            }
            else if (resultado > 40)
            {
                MessageBox.Show("Classificação: Obesidade Grave");
            }
        }
    }
}
