﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PDespesas0030482313027
{
    public partial class frmPrincipal : Form
    {
        public static SqlConnection conexao;

        public frmPrincipal()
        {
            InitializeComponent();
        }


        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            try
            {
                // aqui a conexão vai depende da sua máquina da escola ou particular

                conexao = new SqlConnection("Data Source=kaiq\\SQLSERVER2022;Initial Catalog=LP2;Integrated Security=True");
                conexao.Open();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Erro de banco de dados =/" + ex.Message, "Erro");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Outros Erros =/" + ex.Message, "Erro");
            }
        }



        private void cadastroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmDespesa>().Count() > 0)
            {
                Application.OpenForms["frmDespesa"].BringToFront();
            }
            else
            {
                frmDespesa objDesp = new frmDespesa();
                objDesp.MdiParent = this;
                objDesp.WindowState = FormWindowState.Maximized;
                objDesp.Show();
            }

        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Sobre>().Count() > 0)
            {
                Application.OpenForms["Sobre"].BringToFront();
            }
            else
            {
                Sobre objDesp2 = new Sobre();
                objDesp2.MdiParent = this;
                objDesp2.WindowState = FormWindowState.Maximized;
                objDesp2.Show();
            }
        }

        private void frmPrincipal_Load_1(object sender, EventArgs e)
        {

        }
    }
}
