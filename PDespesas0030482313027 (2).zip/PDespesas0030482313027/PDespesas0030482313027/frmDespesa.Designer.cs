﻿namespace PDespesas0030482313027
{
    partial class frmDespesa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDespesa));
            this.tbDespesa = new System.Windows.Forms.TabControl();
            this.dados = new System.Windows.Forms.TabPage();
            this.dgvDespesa = new System.Windows.Forms.DataGridView();
            this.tbdetalhes = new System.Windows.Forms.TabPage();
            this.mskbxValor = new System.Windows.Forms.MaskedTextBox();
            this.cbxTipo = new System.Windows.Forms.ComboBox();
            this.txtObs = new System.Windows.Forms.TextBox();
            this.dtpData = new System.Windows.Forms.DateTimePicker();
            this.txtID = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.bnvDespesa2 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorCountItem1 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem1 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem1 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem1 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem1 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem1 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.btnNovo2 = new System.Windows.Forms.ToolStripButton();
            this.btnSalvar2 = new System.Windows.Forms.ToolStripButton();
            this.btnAlterar2 = new System.Windows.Forms.ToolStripButton();
            this.btnExcluir2 = new System.Windows.Forms.ToolStripButton();
            this.btnCancelar2 = new System.Windows.Forms.ToolStripButton();
            this.btnSair2 = new System.Windows.Forms.ToolStripButton();
            this.tbDespesa.SuspendLayout();
            this.dados.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDespesa)).BeginInit();
            this.tbdetalhes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bnvDespesa2)).BeginInit();
            this.bnvDespesa2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbDespesa
            // 
            this.tbDespesa.Controls.Add(this.dados);
            this.tbDespesa.Controls.Add(this.tbdetalhes);
            this.tbDespesa.Location = new System.Drawing.Point(30, 94);
            this.tbDespesa.Name = "tbDespesa";
            this.tbDespesa.SelectedIndex = 0;
            this.tbDespesa.Size = new System.Drawing.Size(721, 323);
            this.tbDespesa.TabIndex = 1;
            this.tbDespesa.Tag = "";
            // 
            // dados
            // 
            this.dados.Controls.Add(this.dgvDespesa);
            this.dados.Location = new System.Drawing.Point(4, 25);
            this.dados.Name = "dados";
            this.dados.Padding = new System.Windows.Forms.Padding(3);
            this.dados.Size = new System.Drawing.Size(713, 294);
            this.dados.TabIndex = 0;
            this.dados.Text = "Dados";
            this.dados.UseVisualStyleBackColor = true;
            this.dados.Click += new System.EventHandler(this.dados_Click);
            // 
            // dgvDespesa
            // 
            this.dgvDespesa.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDespesa.Location = new System.Drawing.Point(6, 6);
            this.dgvDespesa.Name = "dgvDespesa";
            this.dgvDespesa.ReadOnly = true;
            this.dgvDespesa.RowHeadersWidth = 51;
            this.dgvDespesa.RowTemplate.Height = 24;
            this.dgvDespesa.Size = new System.Drawing.Size(611, 203);
            this.dgvDespesa.TabIndex = 0;
            this.dgvDespesa.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDespesa_CellContentClick);
            // 
            // tbdetalhes
            // 
            this.tbdetalhes.Controls.Add(this.mskbxValor);
            this.tbdetalhes.Controls.Add(this.cbxTipo);
            this.tbdetalhes.Controls.Add(this.txtObs);
            this.tbdetalhes.Controls.Add(this.dtpData);
            this.tbdetalhes.Controls.Add(this.txtID);
            this.tbdetalhes.Controls.Add(this.label6);
            this.tbdetalhes.Controls.Add(this.label5);
            this.tbdetalhes.Controls.Add(this.label4);
            this.tbdetalhes.Controls.Add(this.label3);
            this.tbdetalhes.Controls.Add(this.label2);
            this.tbdetalhes.Controls.Add(this.label1);
            this.tbdetalhes.Location = new System.Drawing.Point(4, 25);
            this.tbdetalhes.Name = "tbdetalhes";
            this.tbdetalhes.Padding = new System.Windows.Forms.Padding(3);
            this.tbdetalhes.Size = new System.Drawing.Size(713, 294);
            this.tbdetalhes.TabIndex = 1;
            this.tbdetalhes.Text = "Detalhes";
            this.tbdetalhes.UseVisualStyleBackColor = true;
            this.tbdetalhes.Click += new System.EventHandler(this.tbdetalhes_Click);
            // 
            // mskbxValor
            // 
            this.mskbxValor.Enabled = false;
            this.mskbxValor.Location = new System.Drawing.Point(150, 82);
            this.mskbxValor.Name = "mskbxValor";
            this.mskbxValor.Size = new System.Drawing.Size(100, 22);
            this.mskbxValor.TabIndex = 11;
            // 
            // cbxTipo
            // 
            this.cbxTipo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxTipo.Enabled = false;
            this.cbxTipo.FormattingEnabled = true;
            this.cbxTipo.Location = new System.Drawing.Point(150, 204);
            this.cbxTipo.Name = "cbxTipo";
            this.cbxTipo.Size = new System.Drawing.Size(121, 24);
            this.cbxTipo.TabIndex = 10;
            this.cbxTipo.SelectedIndexChanged += new System.EventHandler(this.cbxTipo_SelectedIndexChanged);
            // 
            // txtObs
            // 
            this.txtObs.Enabled = false;
            this.txtObs.Location = new System.Drawing.Point(150, 155);
            this.txtObs.Name = "txtObs";
            this.txtObs.Size = new System.Drawing.Size(100, 22);
            this.txtObs.TabIndex = 9;
            // 
            // dtpData
            // 
            this.dtpData.Enabled = false;
            this.dtpData.Location = new System.Drawing.Point(150, 119);
            this.dtpData.Name = "dtpData";
            this.dtpData.Size = new System.Drawing.Size(200, 22);
            this.dtpData.TabIndex = 7;
            this.dtpData.ValueChanged += new System.EventHandler(this.dtpData_ValueChanged);
            // 
            // txtID
            // 
            this.txtID.Enabled = false;
            this.txtID.Location = new System.Drawing.Point(150, 43);
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(100, 22);
            this.txtID.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(63, 228);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 16);
            this.label6.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(62, 212);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Tipo";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(63, 124);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Data";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Enabled = false;
            this.label3.Location = new System.Drawing.Point(62, 161);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Observação";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(63, 82);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Valor";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(63, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(20, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID";
            // 
            // bnvDespesa2
            // 
            this.bnvDespesa2.AddNewItem = null;
            this.bnvDespesa2.CountItem = this.bindingNavigatorCountItem1;
            this.bnvDespesa2.DeleteItem = null;
            this.bnvDespesa2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.bnvDespesa2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem1,
            this.bindingNavigatorMovePreviousItem1,
            this.bindingNavigatorSeparator3,
            this.bindingNavigatorPositionItem1,
            this.bindingNavigatorCountItem1,
            this.bindingNavigatorSeparator4,
            this.bindingNavigatorMoveNextItem1,
            this.bindingNavigatorMoveLastItem1,
            this.bindingNavigatorSeparator5,
            this.btnNovo2,
            this.btnSalvar2,
            this.btnAlterar2,
            this.btnExcluir2,
            this.btnCancelar2,
            this.btnSair2});
            this.bnvDespesa2.Location = new System.Drawing.Point(0, 0);
            this.bnvDespesa2.MoveFirstItem = this.bindingNavigatorMoveFirstItem1;
            this.bnvDespesa2.MoveLastItem = this.bindingNavigatorMoveLastItem1;
            this.bnvDespesa2.MoveNextItem = this.bindingNavigatorMoveNextItem1;
            this.bnvDespesa2.MovePreviousItem = this.bindingNavigatorMovePreviousItem1;
            this.bnvDespesa2.Name = "bnvDespesa2";
            this.bnvDespesa2.PositionItem = this.bindingNavigatorPositionItem1;
            this.bnvDespesa2.Size = new System.Drawing.Size(800, 27);
            this.bnvDespesa2.TabIndex = 2;
            this.bnvDespesa2.Text = "bindingNavigator1";
            // 
            // bindingNavigatorCountItem1
            // 
            this.bindingNavigatorCountItem1.Name = "bindingNavigatorCountItem1";
            this.bindingNavigatorCountItem1.Size = new System.Drawing.Size(48, 24);
            this.bindingNavigatorCountItem1.Text = "de {0}";
            this.bindingNavigatorCountItem1.ToolTipText = "Número total de itens";
            // 
            // bindingNavigatorMoveFirstItem1
            // 
            this.bindingNavigatorMoveFirstItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem1.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem1.Image")));
            this.bindingNavigatorMoveFirstItem1.Name = "bindingNavigatorMoveFirstItem1";
            this.bindingNavigatorMoveFirstItem1.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem1.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveFirstItem1.Text = "Mover primeiro";
            // 
            // bindingNavigatorMovePreviousItem1
            // 
            this.bindingNavigatorMovePreviousItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem1.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem1.Image")));
            this.bindingNavigatorMovePreviousItem1.Name = "bindingNavigatorMovePreviousItem1";
            this.bindingNavigatorMovePreviousItem1.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem1.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMovePreviousItem1.Text = "Mover anterior";
            // 
            // bindingNavigatorSeparator3
            // 
            this.bindingNavigatorSeparator3.Name = "bindingNavigatorSeparator3";
            this.bindingNavigatorSeparator3.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorPositionItem1
            // 
            this.bindingNavigatorPositionItem1.AccessibleName = "Posição";
            this.bindingNavigatorPositionItem1.AutoSize = false;
            this.bindingNavigatorPositionItem1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem1.Name = "bindingNavigatorPositionItem1";
            this.bindingNavigatorPositionItem1.Size = new System.Drawing.Size(50, 27);
            this.bindingNavigatorPositionItem1.Text = "0";
            this.bindingNavigatorPositionItem1.ToolTipText = "Posição atual";
            // 
            // bindingNavigatorSeparator4
            // 
            this.bindingNavigatorSeparator4.Name = "bindingNavigatorSeparator4";
            this.bindingNavigatorSeparator4.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorMoveNextItem1
            // 
            this.bindingNavigatorMoveNextItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem1.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem1.Image")));
            this.bindingNavigatorMoveNextItem1.Name = "bindingNavigatorMoveNextItem1";
            this.bindingNavigatorMoveNextItem1.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem1.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveNextItem1.Text = "Mover próximo";
            // 
            // bindingNavigatorMoveLastItem1
            // 
            this.bindingNavigatorMoveLastItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem1.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem1.Image")));
            this.bindingNavigatorMoveLastItem1.Name = "bindingNavigatorMoveLastItem1";
            this.bindingNavigatorMoveLastItem1.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem1.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveLastItem1.Text = "Mover último";
            // 
            // bindingNavigatorSeparator5
            // 
            this.bindingNavigatorSeparator5.Name = "bindingNavigatorSeparator5";
            this.bindingNavigatorSeparator5.Size = new System.Drawing.Size(6, 27);
            // 
            // btnNovo2
            // 
            this.btnNovo2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnNovo2.Image = ((System.Drawing.Image)(resources.GetObject("btnNovo2.Image")));
            this.btnNovo2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNovo2.Name = "btnNovo2";
            this.btnNovo2.Size = new System.Drawing.Size(29, 28);
            this.btnNovo2.Text = "Novo";
            this.btnNovo2.Click += new System.EventHandler(this.btnNovo2_Click);
            // 
            // btnSalvar2
            // 
            this.btnSalvar2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnSalvar2.Enabled = false;
            this.btnSalvar2.Image = ((System.Drawing.Image)(resources.GetObject("btnSalvar2.Image")));
            this.btnSalvar2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSalvar2.Name = "btnSalvar2";
            this.btnSalvar2.Size = new System.Drawing.Size(29, 28);
            this.btnSalvar2.Text = "Salvar";
            this.btnSalvar2.Click += new System.EventHandler(this.btnSalvar2_Click);
            // 
            // btnAlterar2
            // 
            this.btnAlterar2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnAlterar2.Image = ((System.Drawing.Image)(resources.GetObject("btnAlterar2.Image")));
            this.btnAlterar2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAlterar2.Name = "btnAlterar2";
            this.btnAlterar2.Size = new System.Drawing.Size(29, 28);
            this.btnAlterar2.Text = "Alterar";
            this.btnAlterar2.Click += new System.EventHandler(this.btnAlterar2_Click);
            // 
            // btnExcluir2
            // 
            this.btnExcluir2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnExcluir2.Image = ((System.Drawing.Image)(resources.GetObject("btnExcluir2.Image")));
            this.btnExcluir2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnExcluir2.Name = "btnExcluir2";
            this.btnExcluir2.Size = new System.Drawing.Size(29, 24);
            this.btnExcluir2.Text = "Excluir";
            this.btnExcluir2.Click += new System.EventHandler(this.btnExcluir2_Click);
            // 
            // btnCancelar2
            // 
            this.btnCancelar2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnCancelar2.Enabled = false;
            this.btnCancelar2.Image = ((System.Drawing.Image)(resources.GetObject("btnCancelar2.Image")));
            this.btnCancelar2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnCancelar2.Name = "btnCancelar2";
            this.btnCancelar2.Size = new System.Drawing.Size(29, 24);
            this.btnCancelar2.Text = "Cancelar";
            this.btnCancelar2.Click += new System.EventHandler(this.btnCancelar2_Click);
            // 
            // btnSair2
            // 
            this.btnSair2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnSair2.Image = ((System.Drawing.Image)(resources.GetObject("btnSair2.Image")));
            this.btnSair2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnSair2.Name = "btnSair2";
            this.btnSair2.Size = new System.Drawing.Size(29, 24);
            this.btnSair2.Text = "Sair";
            this.btnSair2.Click += new System.EventHandler(this.btnSair2_Click);
            // 
            // frmDespesa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.bnvDespesa2);
            this.Controls.Add(this.tbDespesa);
            this.Name = "frmDespesa";
            this.Text = "frmDespesa";
            this.Load += new System.EventHandler(this.frmDespesa_Load);
            this.tbDespesa.ResumeLayout(false);
            this.dados.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDespesa)).EndInit();
            this.tbdetalhes.ResumeLayout(false);
            this.tbdetalhes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bnvDespesa2)).EndInit();
            this.bnvDespesa2.ResumeLayout(false);
            this.bnvDespesa2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TabControl tbDespesa;
        private System.Windows.Forms.TabPage dados;
        private System.Windows.Forms.TabPage tbdetalhes;
        private System.Windows.Forms.DataGridView dgvDespesa;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtObs;
        private System.Windows.Forms.DateTimePicker dtpData;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.ComboBox cbxTipo;
        private System.Windows.Forms.MaskedTextBox mskbxValor;
        private System.Windows.Forms.BindingNavigator bnvDespesa2;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem1;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator3;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem1;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator4;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem1;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator5;
        private System.Windows.Forms.ToolStripButton btnNovo2;
        private System.Windows.Forms.ToolStripButton btnSalvar2;
        private System.Windows.Forms.ToolStripButton btnAlterar2;
        private System.Windows.Forms.ToolStripButton btnExcluir2;
        private System.Windows.Forms.ToolStripButton btnCancelar2;
        private System.Windows.Forms.ToolStripButton btnSair2;
    }
}