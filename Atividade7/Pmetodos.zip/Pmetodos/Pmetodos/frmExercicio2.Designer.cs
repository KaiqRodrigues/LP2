﻿namespace Pmetodos
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.verifica = new System.Windows.Forms.Button();
            this.inserir1 = new System.Windows.Forms.Button();
            this.inserir2 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(123, 126);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Palavra 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(123, 207);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Palavra 2";
            // 
            // verifica
            // 
            this.verifica.Location = new System.Drawing.Point(216, 312);
            this.verifica.Name = "verifica";
            this.verifica.Size = new System.Drawing.Size(75, 32);
            this.verifica.TabIndex = 2;
            this.verifica.Text = "Verifica iguais";
            this.verifica.UseVisualStyleBackColor = true;
            this.verifica.Click += new System.EventHandler(this.Verifica_Click);
            // 
            // inserir1
            // 
            this.inserir1.Location = new System.Drawing.Point(324, 312);
            this.inserir1.Name = "inserir1";
            this.inserir1.Size = new System.Drawing.Size(75, 32);
            this.inserir1.TabIndex = 3;
            this.inserir1.Text = "Inserir 1";
            this.inserir1.UseVisualStyleBackColor = true;
            this.inserir1.Click += new System.EventHandler(this.Inserir1_Click);
            // 
            // inserir2
            // 
            this.inserir2.Location = new System.Drawing.Point(440, 312);
            this.inserir2.Name = "inserir2";
            this.inserir2.Size = new System.Drawing.Size(75, 32);
            this.inserir2.TabIndex = 4;
            this.inserir2.Text = "Inserir 2";
            this.inserir2.UseVisualStyleBackColor = true;
            this.inserir2.Click += new System.EventHandler(this.Inserir2_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(216, 123);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 26);
            this.textBox1.TabIndex = 5;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(216, 207);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 26);
            this.textBox2.TabIndex = 6;
            // 
            // frmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.inserir2);
            this.Controls.Add(this.inserir1);
            this.Controls.Add(this.verifica);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "frmExercicio2";
            this.Text = "frmExercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button verifica;
        private System.Windows.Forms.Button inserir1;
        private System.Windows.Forms.Button inserir2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
    }
}