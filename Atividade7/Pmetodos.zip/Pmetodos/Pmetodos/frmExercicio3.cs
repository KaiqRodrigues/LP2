﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {

        }

        private void Verifica_Click(object sender, EventArgs e)
        {
            int posicao = textBox2.Text.IndexOf(textBox1.Text, StringComparison.OrdinalIgnoreCase);

            while(posicao >= 0)
            {
                textBox2.Text = textBox2.Text.Substring(0, posicao) + textBox2.Text.Substring(posicao + textBox1.Text.Length, textBox2.Text.Length - posicao - textBox1.Text.Length);
                posicao = textBox2.Text.IndexOf(textBox1.Text, StringComparison.OrdinalIgnoreCase);
            }
        }
    }
}
