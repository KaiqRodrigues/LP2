﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void Verifica_Click(object sender, EventArgs e)
        {
            if (String.Compare(textBox1.Text, textBox2.Text, true) == 0)
            {
                MessageBox.Show("Sao iguais");
            }
            else
                MessageBox.Show("Sao diferentes");
        }

        private void Inserir1_Click(object sender, EventArgs e)
        {
            int meio = textBox2.Text.Length / 2;

            textBox2.Text = textBox2.Text.Substring(0, meio) + textBox1.Text + textBox2.Text.Substring(meio, textBox2.Text.Length - meio);

        }

        private void Inserir2_Click(object sender, EventArgs e)
        {
            int metade = textBox1.Text.Length / 2;
            textBox2.Text = textBox1.Text.Insert(metade, "**");
        }
    }
}
