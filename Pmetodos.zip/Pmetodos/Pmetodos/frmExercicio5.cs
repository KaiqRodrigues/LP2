﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtnSortear_Click(object sender, EventArgs e)
        {
            int num1, num2;

            if (!int.TryParse(number1.Text, out num1) || !int.TryParse(number2.Text, out num2))
            {
                MessageBox.Show("Dados invalidos!");
            }
            else
            {
                if((num1 <= 0) || (num2 <= 0) || (num1 >= num2))
                {
                    MessageBox.Show("O numero 1 tem que ser maior que o numero2");
                }
                else
                {
                    Random objR = new Random();
                    int aleatorio = objR.Next(num1,num2);
                    MessageBox.Show($"O vencedor é o numero: {aleatorio}");
                }
            }
        }
    }
}
