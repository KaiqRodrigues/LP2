﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {

        }

        private void Verifica_Click(object sender, EventArgs e)
        {
            int posicao = Palavra2.Text.IndexOf(Palavra1.Text, StringComparison.OrdinalIgnoreCase);

            while(posicao >= 0)
            {
                Palavra2.Text = Palavra2.Text.Substring(0, posicao) + Palavra2.Text.Substring(posicao + Palavra1.Text.Length, Palavra2.Text.Length - posicao - Palavra1.Text.Length);
                posicao = Palavra2.Text.IndexOf(Palavra1.Text, StringComparison.OrdinalIgnoreCase);
            }
        }

        private void BtnRemover2_Click(object sender, EventArgs e)
        {
            Palavra2.Text = Palavra2.Text.Replace(Palavra1.Text, "");
        }

        private void BtnInverte_Click(object sender, EventArgs e)
        {
            //tranformando string em array para reversao
            char[] vetor = Palavra1.Text.ToCharArray();
            //inverter array
            Array.Reverse(vetor);
            Palavra2.Text = "";
            //Voltar para string
            foreach(var c in vetor)
            {
                Palavra2.Text += c;
            }
        }
    }
}
