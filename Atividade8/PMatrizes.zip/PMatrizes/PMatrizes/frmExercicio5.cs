﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void frmExercicio5_Load(object sender, EventArgs e)
        {
            string[] words = new string[2];
            int[] len = new int[2];

            string auxiliar = "";

            for (int i = 0; i < 2; i++)
            {
                auxiliar = Interaction.InputBox($"Entre com o nome {i + 1}", "Entrada de dados");
                if (auxiliar == "")
                    i--;
                else
                {
                    words[i] = auxiliar;
                }

            }

            int auxFor = 0;

            foreach (string palavra in words)
            {
                int aux = 0;

                for (int i = 0; i < palavra.Length; i++)
                {
                    if (palavra[i] != ' ')
                    {
                        aux++;
                    }
                }
                len[auxFor] = aux;
                auxFor++;

            }

            for (int i = 0; i < words.Length; i++)
            {
                string aux = $"{words[i]} tem {len[i]} carecteres";
                lboxNames.Items.Add(aux);
            }
        }

        private void lboxNomes_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
    }

