﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string aux = "";
            string saida = "";
            for (var i = 0; i < 20; i++)
            {
                aux = Interaction.InputBox($"Digite o {i + 1}° numero", "Entrada de Dados");

                if (aux == "")
                    return;

                if (!int.TryParse(aux, out vetor[i]))
                {
                    MessageBox.Show("Valor invalido!");
                    i--;
                }
                else
                {
                    saida = vetor[i] + saida;
                }
            }
            Array.Reverse(vetor);

            //mbox apenas mostra strings, entao necessitase transfromar o vetor em string
            foreach (var c in vetor)
            {
                aux += c + "\n"; //vai colocar cada caracter invertido do vetor na string "aux"
            }
            MessageBox.Show(aux);
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            double[] soma = new double[20];
            string auxiliar = "";
            int aluno, nota;

            for (aluno = 0; aluno < 20; aluno++)
            {
                for (nota = 0; nota < 3; nota++)
                {
                    auxiliar = Interaction.InputBox($"Digite a {nota + 1}° nota do {aluno + 1}° aluno: ");
                    if (auxiliar == "")
                    {
                        return;
                    }
                    if (!double.TryParse(auxiliar, out notas[aluno, nota]))
                    {
                        MessageBox.Show("Entrada de valor invalido!");
                        nota--;
                    }

                    else if (notas[aluno, nota] < 0 || notas[aluno, nota] > 10)
                    {
                        MessageBox.Show("Valor de nota invalido");
                        nota--;
                    }
                    else
                        soma[aluno] = soma[aluno] + notas[aluno, nota];
                }
            }
            for (int i = 0; i < 20; i++)
            {
                MessageBox.Show($"Aluno: {i + 1} Media: {soma[i] / 3}");
            }

        }

        private void btn3_Click(object sender, EventArgs e)
        {
            string[] Alunos = { "Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Tobby" };
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
            }
            MessageBox.Show("C) " + Total.ToString());
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            ArrayList pessoas = new ArrayList();
            pessoas.Add("Ana");
            pessoas.Add("André");
            pessoas.Add("Débora");
            pessoas.Add("Fátima");
            pessoas.Add("João");
            pessoas.Add("Janete");
            pessoas.Add("Otávio");
            pessoas.Add("Marcelo");
            pessoas.Add("Pedro");
            pessoas.Add("Thais");

            pessoas.Remove("Otávio");
            string texto = "";
            foreach (var n in pessoas)
            {
                texto += n + "\n";

            }
            MessageBox.Show(texto.ToString());
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            frmExercicio5 form = new frmExercicio5();
            form.ShowDialog();
        }
    }
    
}
