namespace Desconto_Inss
{
    public partial class Form1 : Form
    {
        double bruto;
        double aliqINSS, aliqIRPF, familia, descINSS, descIRPF;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void mskSalarioBruto_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskSalarioBruto.Text, out bruto))
            {
                MessageBox.Show("Valor de Salario bruto invalido!");
                mskSalarioBruto.Focus();
            }

        }

        private void txtAliqINSS_TextChanged(object sender, EventArgs e)
        {
        }

        private void btnVerificarDesc_Click(object sender, EventArgs e)
        {
            //INSS
            if (double.Parse(mskSalarioBruto.Text) <= 800.47)
            {
                aliqINSS = 7.65;
                txtAliqINSS.Text = aliqINSS.ToString() + "%";
                descINSS = ((aliqINSS / 100) * bruto);
                txtDescINSS.Text = (descINSS).ToString();
            }
            else if (double.Parse(mskSalarioBruto.Text) <= 1050)
            {
                aliqINSS = 8.65;
                txtAliqINSS.Text = aliqINSS.ToString() + "%";
                descINSS = ((aliqINSS / 100) * bruto);
                txtDescINSS.Text = (descINSS).ToString();
            }
            else if (double.Parse(mskSalarioBruto.Text) <= 1400.77)
            {
                aliqINSS = 9;
                txtAliqINSS.Text = aliqINSS.ToString() + "%";
                descINSS = ((aliqINSS / 100) * bruto);
                txtDescINSS.Text = (descINSS).ToString();
            }
            else if (double.Parse(mskSalarioBruto.Text) <= 2801.56)
            {
                aliqINSS = 11;
                txtAliqINSS.Text = aliqINSS.ToString() + "%";
                descINSS = ((aliqINSS / 100) * bruto);
                txtDescINSS.Text = (descINSS).ToString();
            }
            else
            {
                aliqINSS = 11;
                txtAliqINSS.Text = aliqINSS.ToString() + "%";
                descINSS = (308.17);
                txtDescINSS.Text = (descINSS).ToString();
            }

            //IRPF
            if (double.Parse(mskSalarioBruto.Text) < 1257.12)
            {
                txtAliqIRPF.Text = "Isento";
                txtIRPF.Text = "Isento";
            }
            else if (double.Parse(mskSalarioBruto.Text) <= 2512.08)
            {
                aliqIRPF = 15;
                txtAliqIRPF.Text = aliqIRPF.ToString() + "%";
                descIRPF = (aliqIRPF / 100 * bruto);
                txtIRPF.Text = (aliqIRPF / 100 * bruto).ToString();
            }
            else
            {
                aliqIRPF = 27.5;
                txtAliqIRPF.Text = aliqIRPF.ToString() + "%";
                descIRPF = (aliqIRPF / 100 * bruto);
                txtIRPF.Text = (aliqIRPF / 100 * bruto).ToString();
            }

            //Familia
            if (double.Parse(mskSalarioBruto.Text) <= 435.52)
            {
                familia = double.Parse(numFilhos.Text) * 22.33;
                txtSalFamilia.Text = "R$" + familia.ToString();
            }

            else if ((double.Parse(mskSalarioBruto.Text) < 654.61))
            {
                familia = double.Parse(numFilhos.Text) * 15.74;
                txtSalFamilia.Text = "R$" + familia.ToString();
            }
            else
            {
                familia = double.Parse(numFilhos.Text) * 0;
                txtSalFamilia.Text = "R$" + familia.ToString();
            }


            //salario liquido

            txtSalLiquido.Text = "R$" + (bruto - descINSS - descIRPF + familia).ToString();
        }
    }
}