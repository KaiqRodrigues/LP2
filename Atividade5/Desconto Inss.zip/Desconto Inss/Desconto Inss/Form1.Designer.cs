﻿namespace Desconto_Inss
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            txtAliqIRPF = new TextBox();
            txtAliqINSS = new TextBox();
            txtSalLiquido = new TextBox();
            txtSalFamilia = new TextBox();
            txtDescINSS = new TextBox();
            txtIRPF = new TextBox();
            btnVerificarDesc = new Button();
            mskNome = new MaskedTextBox();
            mskSalarioBruto = new MaskedTextBox();
            numFilhos = new NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)numFilhos).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(39, 111);
            label1.Name = "label1";
            label1.Size = new Size(95, 20);
            label1.TabIndex = 0;
            label1.Text = "Salario Bruto";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(39, 149);
            label2.Name = "label2";
            label2.Size = new Size(126, 20);
            label2.TabIndex = 1;
            label2.Text = "Numero de Filhos";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(39, 272);
            label3.Name = "label3";
            label3.Size = new Size(101, 20);
            label3.TabIndex = 2;
            label3.Text = "Aliquota INSS";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(39, 397);
            label4.Name = "label4";
            label4.Size = new Size(109, 20);
            label4.TabIndex = 3;
            label4.Text = "Salario Liquido";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(42, 352);
            label5.Name = "label5";
            label5.Size = new Size(106, 20);
            label5.TabIndex = 4;
            label5.Text = "Salario Familia";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(39, 308);
            label6.Name = "label6";
            label6.Size = new Size(98, 20);
            label6.TabIndex = 5;
            label6.Text = "Aliquota IRPF";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(39, 76);
            label7.Name = "label7";
            label7.Size = new Size(131, 20);
            label7.TabIndex = 6;
            label7.Text = "Nome Funcionario";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(403, 315);
            label8.Name = "label8";
            label8.Size = new Size(104, 20);
            label8.TabIndex = 7;
            label8.Text = "Desconto IRPF";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(403, 272);
            label9.Name = "label9";
            label9.Size = new Size(107, 20);
            label9.TabIndex = 8;
            label9.Text = "Desconto INSS";
            // 
            // txtAliqIRPF
            // 
            txtAliqIRPF.Enabled = false;
            txtAliqIRPF.Location = new Point(182, 305);
            txtAliqIRPF.Name = "txtAliqIRPF";
            txtAliqIRPF.Size = new Size(125, 27);
            txtAliqIRPF.TabIndex = 10;
            // 
            // txtAliqINSS
            // 
            txtAliqINSS.Enabled = false;
            txtAliqINSS.Location = new Point(182, 269);
            txtAliqINSS.Name = "txtAliqINSS";
            txtAliqINSS.Size = new Size(125, 27);
            txtAliqINSS.TabIndex = 11;
            txtAliqINSS.TextChanged += txtAliqINSS_TextChanged;
            // 
            // txtSalLiquido
            // 
            txtSalLiquido.Enabled = false;
            txtSalLiquido.Location = new Point(182, 390);
            txtSalLiquido.Name = "txtSalLiquido";
            txtSalLiquido.Size = new Size(125, 27);
            txtSalLiquido.TabIndex = 13;
            // 
            // txtSalFamilia
            // 
            txtSalFamilia.Enabled = false;
            txtSalFamilia.Location = new Point(182, 352);
            txtSalFamilia.Name = "txtSalFamilia";
            txtSalFamilia.Size = new Size(125, 27);
            txtSalFamilia.TabIndex = 14;
            // 
            // txtDescINSS
            // 
            txtDescINSS.Enabled = false;
            txtDescINSS.Location = new Point(541, 272);
            txtDescINSS.Name = "txtDescINSS";
            txtDescINSS.Size = new Size(125, 27);
            txtDescINSS.TabIndex = 15;
            // 
            // txtIRPF
            // 
            txtIRPF.Enabled = false;
            txtIRPF.Location = new Point(541, 315);
            txtIRPF.Name = "txtIRPF";
            txtIRPF.Size = new Size(125, 27);
            txtIRPF.TabIndex = 16;
            // 
            // btnVerificarDesc
            // 
            btnVerificarDesc.Location = new Point(284, 203);
            btnVerificarDesc.Name = "btnVerificarDesc";
            btnVerificarDesc.Size = new Size(157, 29);
            btnVerificarDesc.TabIndex = 17;
            btnVerificarDesc.Text = "Verificar Desconto";
            btnVerificarDesc.UseVisualStyleBackColor = true;
            btnVerificarDesc.Click += btnVerificarDesc_Click;
            // 
            // mskNome
            // 
            mskNome.Location = new Point(182, 76);
            mskNome.Name = "mskNome";
            mskNome.Size = new Size(325, 27);
            mskNome.TabIndex = 1;
            // 
            // mskSalarioBruto
            // 
            mskSalarioBruto.Location = new Point(182, 111);
            mskSalarioBruto.Name = "mskSalarioBruto";
            mskSalarioBruto.Size = new Size(125, 27);
            mskSalarioBruto.TabIndex = 2;
            mskSalarioBruto.Text = "________,__";
            mskSalarioBruto.Validated += mskSalarioBruto_Validated;
            // 
            // numFilhos
            // 
            numFilhos.Location = new Point(182, 147);
            numFilhos.Name = "numFilhos";
            numFilhos.Size = new Size(150, 27);
            numFilhos.TabIndex = 3;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(numFilhos);
            Controls.Add(mskSalarioBruto);
            Controls.Add(mskNome);
            Controls.Add(btnVerificarDesc);
            Controls.Add(txtIRPF);
            Controls.Add(txtDescINSS);
            Controls.Add(txtSalFamilia);
            Controls.Add(txtSalLiquido);
            Controls.Add(txtAliqINSS);
            Controls.Add(txtAliqIRPF);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)numFilhos).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private TextBox txtAliqIRPF;
        private TextBox txtAliqINSS;
        private TextBox txtSalLiquido;
        private TextBox txtSalFamilia;
        private TextBox txtDescINSS;
        private TextBox txtIRPF;
        private Button btnVerificarDesc;
        private MaskedTextBox mskNome;
        private MaskedTextBox mskSalarioBruto;
        private NumericUpDown numFilhos;
    }
}